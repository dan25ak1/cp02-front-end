function digit(value) {
    document.getElementById('result').value += value;
  }
  function addFloat() {
    let currentValue = document.getElementById('result').value;
    if (currentValue.indexOf('.') === -1) {
      document.getElementById('result').value += '.';
    }
  }
  function clearAll() {
    document.getElementById('result').value = '';
  }
  function equals() {
    let result = document.getElementById('result').value;
    try {
      let finalResult = evalExpression(result);
      document.getElementById('result').value = finalResult;
    } catch (error) {
      document.getElementById('result').value = 'Erro :(';
      setTimeout(clearError, 700); 
    }
  }
  function evalExpression(expression) {
    expression = expression.replace(/x/g, '*');
    return Function('"use strict";return (' + expression + ')')();
  }
  function clearError() {
    document.getElementById('result').value = '';
  }